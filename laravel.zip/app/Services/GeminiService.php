<?php

namespace App\Services;

use Illuminate\Support\Facades\Http;

class GeminiService
{
    private $apiKey;
    // Using v1beta for gemini-2.5-flash support (gemini-1.5-flash is deprecated)
    private $baseUrl = 'https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent';

    public function __construct($apiKey = null)
    {
        // Use provided key, or fallback to static key
        $this->apiKey = $apiKey ?: 'AIzaSyAAjM6pFbn9brrW1J_Wt6BPlp_BO9EGEU8';
    }

    /**
     * Test connection to Gemini API
     */
    public function testConnection()
    {
        try {
            $response = Http::timeout(15)
                ->connectTimeout(10)
                ->post($this->baseUrl . '?key=' . $this->apiKey, [
                    'contents' => [
                        [
                            'parts' => [
                                ['text' => 'Hello']
                            ]
                        ]
                    ]
                ]);

            if ($response->successful()) {
                return [
                    'success' => true,
                    'message' => 'Connection successful'
                ];
            }

            return [
                'success' => false,
                'message' => 'API returned error: ' . $response->body(),
                'status' => $response->status()
            ];
        } catch (\Exception $e) {
            return [
                'success' => false,
                'message' => 'Connection failed: ' . $e->getMessage()
            ];
        }
    }

    /**
     * Generate content using Gemini AI with retry logic
     */
    public function generateContent($prompt, $retries = 2)
    {
        $attempt = 0;
        $lastError = null;

        while ($attempt <= $retries) {
            try {
                // Increase timeout and add connection timeout
                $response = Http::timeout(60)
                    ->connectTimeout(30)
                    ->retry(2, 1000) // Retry 2 times with 1 second delay
                    ->post($this->baseUrl . '?key=' . $this->apiKey, [
                        'contents' => [
                            [
                                'parts' => [
                                    ['text' => $prompt]
                                ]
                            ]
                        ],
                        'generationConfig' => [
                            'temperature' => 0.7,
                            'maxOutputTokens' => 8192,
                        ]
                    ]);

                if ($response->successful()) {
                    $data = $response->json();
                    
                    // Validate response structure
                    if (isset($data['candidates'][0]['content']['parts'][0]['text'])) {
                        return $data['candidates'][0]['content']['parts'][0]['text'];
                    }
                    
                    // Check for error in response
                    if (isset($data['error'])) {
                        $errorMsg = $data['error']['message'] ?? 'Unknown API error';
                        return "API Error: {$errorMsg}";
                    }
                    
                    return 'No response generated from AI';
                }

                // Handle HTTP errors
                $statusCode = $response->status();
                $errorBody = $response->body();
                
                return "HTTP Error {$statusCode}: {$errorBody}";
                
            } catch (\Illuminate\Http\Client\ConnectionException $e) {
                $lastError = $e;
                $attempt++;
                
                // If not last attempt, wait before retry (exponential backoff)
                if ($attempt <= $retries) {
                    sleep(pow(2, $attempt)); // 2, 4, 8 seconds
                    continue;
                }
                
                // Last attempt failed
                return "Connection Error: Unable to reach Gemini API after {$retries} retries. Please check your internet connection or try again later. Details: " . $e->getMessage();
                
            } catch (\Exception $e) {
                $lastError = $e;
                $attempt++;
                
                if ($attempt <= $retries) {
                    sleep(1);
                    continue;
                }
                
                return 'Error: ' . $e->getMessage();
            }
        }

        return 'Error: Maximum retries exceeded. ' . ($lastError ? $lastError->getMessage() : 'Unknown error');
    }

    /**
     * Get financial insights based on user data
     */
    public function getFinancialInsights($userData)
    {
        $prompt = "You are an expert financial advisor. Analyze this user's financial data and provide comprehensive insights:\n\n";
        $prompt .= "📊 FINANCIAL OVERVIEW:\n";
        $prompt .= "Total Income: ₱" . number_format($userData['totalIncome'], 2) . "\n";
        $prompt .= "Total Expenses: ₱" . number_format($userData['totalExpenses'], 2) . "\n";
        $prompt .= "Current Balance: ₱" . number_format($userData['balance'], 2) . "\n";
        $prompt .= "Current Month Income: ₱" . number_format($userData['currentMonthIncome'], 2) . "\n";
        $prompt .= "Current Month Expenses: ₱" . number_format($userData['currentMonthExpenses'], 2) . "\n\n";
        
        if (!empty($userData['categoryStats'])) {
            $prompt .= "💳 TOP SPENDING CATEGORIES:\n";
            foreach ($userData['categoryStats'] as $cat) {
                $prompt .= "- {$cat['name']}: ₱" . number_format($cat['expense'], 2) . "\n";
            }
            $prompt .= "\n";
        }

        $prompt .= "Please provide a detailed analysis with:\n\n";
        $prompt .= "## 🎯 Key Financial Insights\n";
        $prompt .= "Provide 4-5 specific, actionable insights about their financial situation.\n\n";
        
        $prompt .= "## ⚠️ Areas of Concern\n";
        $prompt .= "Identify any red flags or concerning patterns.\n\n";
        
        $prompt .= "## ✅ Strengths\n";
        $prompt .= "Highlight what they're doing well.\n\n";
        
        $prompt .= "## 💡 Actionable Recommendations\n";
        $prompt .= "Provide 3-5 specific, practical steps they can take immediately.\n\n";
        
        $prompt .= "## 📈 Financial Health Score\n";
        $prompt .= "Rate their overall financial health on a scale of 1-10 and explain why.\n\n";
        
        $prompt .= "Format your response in clear markdown with emojis for better readability. Be specific with numbers and percentages.";

        return $this->generateContent($prompt);
    }

    /**
     * Get budget recommendations
     */
    public function getBudgetRecommendations($spendingData)
    {
        $prompt = "You are a financial planning expert. Based on this spending pattern, create detailed monthly budget recommendations:\n\n";
        
        $prompt .= "💰 CURRENT SPENDING BREAKDOWN:\n";
        $totalSpent = 0;
        foreach ($spendingData as $category) {
            $prompt .= "- {$category['name']}: ₱" . number_format($category['spent'], 2) . "\n";
            $totalSpent += $category['spent'];
        }
        $prompt .= "\nTotal Monthly Spending: ₱" . number_format($totalSpent, 2) . "\n\n";

        $prompt .= "Please provide:\n\n";
        $prompt .= "## 📊 Recommended Budget Allocation\n";
        $prompt .= "For each category, provide:\n";
        $prompt .= "- Recommended monthly budget amount\n";
        $prompt .= "- Percentage of total income (if overspending, suggest reduction)\n";
        $prompt .= "- Brief justification\n\n";
        
        $prompt .= "## 🎯 Budget Strategy\n";
        $prompt .= "Apply the 50/30/20 rule:\n";
        $prompt .= "- 50% for Needs (essentials)\n";
        $prompt .= "- 30% for Wants (lifestyle)\n";
        $prompt .= "- 20% for Savings & Debt\n\n";
        
        $prompt .= "## 💡 Quick Wins\n";
        $prompt .= "Identify 2-3 categories where they can easily cut costs.\n\n";
        
        $prompt .= "## 📈 Expected Impact\n";
        $prompt .= "Calculate potential monthly savings if recommendations are followed.\n\n";
        
        $prompt .= "Format as clear markdown with specific peso amounts. Be realistic and practical.";

        return $this->generateContent($prompt);
    }

    /**
     * Analyze spending patterns
     */
    public function analyzeSpending($transactions)
    {
        $prompt = "You are a data analyst specializing in personal finance. Analyze these recent transactions and provide deep insights:\n\n";
        
        $prompt .= "📝 RECENT TRANSACTIONS:\n";
        foreach ($transactions as $tx) {
            $prompt .= "- {$tx['category']}: ₱" . number_format($tx['amount'], 2) . " ({$tx['type']}) on {$tx['date']}\n";
        }

        $prompt .= "\n\nProvide a comprehensive analysis:\n\n";
        
        $prompt .= "## 📊 Spending Patterns\n";
        $prompt .= "Identify recurring patterns, habits, and trends in the data.\n\n";
        
        $prompt .= "## 🔍 Key Observations\n";
        $prompt .= "Highlight the most important findings from the transaction history.\n\n";
        
        $prompt .= "## ⚠️ Anomalies & Red Flags\n";
        $prompt .= "Identify any unusual, irregular, or concerning expenses.\n\n";
        
        $prompt .= "## 💡 Optimization Opportunities\n";
        $prompt .= "Suggest specific ways to save money based on the spending patterns.\n\n";
        
        $prompt .= "## 📈 Trend Analysis\n";
        $prompt .= "Describe if spending is increasing, decreasing, or stable. Predict future trends.\n\n";
        
        $prompt .= "## 🎯 Action Items\n";
        $prompt .= "Provide 3-5 specific, actionable steps to improve spending habits.\n\n";
        
        $prompt .= "Be specific with numbers, percentages, and concrete examples. Format in clear markdown.";

        return $this->generateContent($prompt);
    }

    /**
     * Chat with AI financial advisor
     */
    public function chat($message, $context = [])
    {
        $mode = $context['mode'] ?? 'conversation';
        $speed = $context['speed'] ?? 'fast';

        $prompt = "You are an expert financial advisor and data analyst. You help users understand their finances through clear, actionable advice.\n\n";
        
        // Mode-specific instructions
        if ($mode === 'statistical') {
            $prompt .= "MODUS: STATISTICAL ANALYST\n";
            $prompt .= "- Your PRIMARY goal is to provide data, numbers, and visualizations.\n";
            $prompt .= "- You MUST generate a chart for every query if possible.\n";
            $prompt .= "- Focus on trends, percentages, and hard data.\n\n";
        } else {
            $prompt .= "MODUS: CONVERSATIONAL ASSISTANT\n";
            $prompt .= "- Be friendly, empathetic, and easy to talk to.\n";
            $prompt .= "- Use natural language and avoid overwhelming the user with too many numbers unless asked.\n\n";
        }

        if (!empty($context)) {
            $prompt .= "📊 USER'S FINANCIAL CONTEXT:\n";
            $prompt .= "- Current Balance: ₱" . number_format($context['balance'] ?? 0, 2) . "\n";
            $prompt .= "- Monthly Income: ₱" . number_format($context['monthlyIncome'] ?? 0, 2) . "\n";
            $prompt .= "- Monthly Expenses: ₱" . number_format($context['monthlyExpenses'] ?? 0, 2) . "\n";
             
            $savingsRate = 0;
            if (($context['monthlyIncome'] ?? 0) > 0) {
                 $savingsRate = (($context['monthlyIncome'] - $context['monthlyExpenses']) / $context['monthlyIncome']) * 100;
            }
            $prompt .= "- Savings Rate: " . number_format($savingsRate, 1) . "%\n\n";
        }

        $prompt .= "USER QUESTION: " . $message . "\n\n";
        
        // Speed-specific pre-computation
        if ($speed === 'planning') {
            $prompt .= "INSTRUCTION: PLAN BEFORE ANSWERING\n";
            $prompt .= "Before generating the final response, think step-by-step about the user's situation. Consider:\n";
            $prompt .= "1. What is the root cause of their question?\n";
            $prompt .= "2. What are the long-term implications?\n";
            $prompt .= "3. What is the most sustainable advice?\n";
            $prompt .= "Then, provide a well-structured, deep response.\n\n";
        }

        // Personality tuning
        if ($mode === 'conversation') {
             $prompt .= "MODUS: EMPATHETIC FINANCIAL COACH\n";
             $prompt .= "- Be warm, encouraging, and human-like. Use phrases like 'I understand', 'That's a great goal', or 'Let's tackle this together'.\n";
             $prompt .= "- Avoid sounding robotic or overly formal. Imagine you are a knowledgeable friend.\n";
        }

        $prompt .= "INSTRUCTIONS:\n";
        $prompt .= "- Provide a helpful, specific, and actionable response\n";
        $prompt .= "- Use the financial context to give personalized advice\n";
        $prompt .= "- Include specific numbers and calculations when relevant\n";
        $prompt .= "- Format response in clear markdown with sections if needed\n";
        $prompt .= "- Use emojis to make it engaging\n";
        
        $prompt .= "IMPORTANT - DATA & SUGGESTIONS:\n";
        $prompt .= "You MUST ALWAYS end your response with a JSON object containing:\n";
        $prompt .= "1. 'suggestions': An array of 2-3 short, relevant follow-up questions or actions the user might want to take (e.g., 'Show me a graph', 'Forecast next month', 'Analyze food spending').\n";
        $prompt .= "2. 'chart': (Optional) A chart object IF the user asked for data or if a chart would be very helpful.\n";
        
        $prompt .= "The JSON must follow this exact structure:\n";
        $prompt .= "```json\n";
        $prompt .= "{\n";
        $prompt .= "  \"suggestions\": [\"Next step 1\", \"Next step 2\"],\n";
        $prompt .= "  \"chart\": {\n";
        $prompt .= "    \"type\": \"bar\" | \"pie\" | \"line\",\n";
        $prompt .= "    \"title\": \"Chart Title\",\n";
        $prompt .= "    \"data\": [\n";
        $prompt .= "      { \"name\": \"Label 1\", \"value\": 100 },\n";
        $prompt .= "      { \"name\": \"Label 2\", \"value\": 200 }\n";
        $prompt .= "    ]\n";
        $prompt .= "  }\n";
        $prompt .= "}\n";
        $prompt .= "```\n";
        $prompt .= "NOTE: The 'chart' key is optional and can be null if no chart is needed. 'suggestions' is REQUIRED.\n";
        $prompt .= "Do not wrap the JSON in markdown code blocks in the final output if possible, or ensure it is clearly separated.\n\n";
        
        $prompt .= "Respond now:";

        return $this->generateContent($prompt);
    }
}
