<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Services\GeminiService;
use App\Models\CategoryBudget;
use Illuminate\Support\Facades\Crypt;

class AIController extends Controller
{
    /**
     * Save or update user's Gemini API key
     */
    public function saveApiKey(Request $request)
    {
        $request->validate([
            'api_key' => 'required|string',
        ]);

        $user = auth()->user();
        $user->gemini_api_key = Crypt::encryptString($request->api_key);
        $user->save();

        return response()->json([
            'message' => 'API key saved successfully',
            'has_api_key' => true,
        ]);
    }

    /**
     * Check if user has API key
     */
    public function checkApiKey()
    {
        $user = auth()->user();
        return response()->json([
            'has_api_key' => !empty($user->gemini_api_key),
        ]);
    }

    /**
     * Test API connection
     */
    public function testApiConnection()
    {
        $user = auth()->user();
        $apiKey = !empty($user->gemini_api_key) ? Crypt::decryptString($user->gemini_api_key) : null;
        
        $gemini = new GeminiService($apiKey);
        $result = $gemini->testConnection();
        
        return response()->json($result);
    }

    /**
     * Get AI financial insights
     */
    public function getInsights(Request $request)
    {
        $user = auth()->user();

        // Gather user financial data
        $totalIncome = $user->transactions()->where('type', 'income')->sum('amount');
        $totalExpenses = $user->transactions()->where('type', 'expense')->sum('amount');
        $balance = $totalIncome - $totalExpenses;

        $currentMonthIncome = $user->transactions()
            ->where('type', 'income')
            ->whereMonth('date', now()->month)
            ->whereYear('date', now()->year)
            ->sum('amount');

        $currentMonthExpenses = $user->transactions()
            ->where('type', 'expense')
            ->whereMonth('date', now()->month)
            ->whereYear('date', now()->year)
            ->sum('amount');

        // Get category stats
        $categoryStats = $user->transactions()
            ->with('category')
            ->get()
            ->groupBy('category_id')
            ->map(function ($items) {
                $category = $items->first()->category;
                return [
                    'name' => $category ? $category->name : 'Unknown',
                    'expense' => $items->where('type', 'expense')->sum('amount'),
                ];
            })
            ->sortByDesc('expense')
            ->take(5)
            ->values();

        $userData = [
            'totalIncome' => $totalIncome,
            'totalExpenses' => $totalExpenses,
            'balance' => $balance,
            'currentMonthIncome' => $currentMonthIncome,
            'currentMonthExpenses' => $currentMonthExpenses,
            'categoryStats' => $categoryStats,
        ];

        $apiKey = !empty($user->gemini_api_key) ? Crypt::decryptString($user->gemini_api_key) : null;
        $gemini = new GeminiService($apiKey);
        $insights = $gemini->getFinancialInsights($userData);

        return response()->json([
            'insights' => $insights,
            'data' => $userData,
        ]);
    }

    /**
     * Analyze spending patterns
     */
    public function analyzeSpending(Request $request)
    {
        $user = auth()->user();

        $transactions = $user->transactions()
            ->with('category')
            ->orderBy('date', 'desc')
            ->take(20)
            ->get()
            ->map(function ($tx) {
                return [
                    'category' => $tx->category ? $tx->category->name : 'Unknown',
                    'amount' => $tx->amount,
                    'type' => $tx->type,
                    'date' => $tx->date,
                ];
            });

        $apiKey = !empty($user->gemini_api_key) ? Crypt::decryptString($user->gemini_api_key) : null;
        $gemini = new GeminiService($apiKey);
        $analysis = $gemini->analyzeSpending($transactions);

        return response()->json([
            'analysis' => $analysis,
        ]);
    }

    /**
     * Get budget recommendations
     */
    public function getBudgetRecommendations(Request $request)
    {
        $user = auth()->user();

        // Get spending by category for current month
        $spendingData = $user->transactions()
            ->with('category')
            ->where('type', 'expense')
            ->whereMonth('date', now()->month)
            ->whereYear('date', now()->year)
            ->get()
            ->groupBy('category_id')
            ->map(function ($items) {
                $category = $items->first()->category;
                return [
                    'name' => $category ? $category->name : 'Unknown',
                    'spent' => $items->sum('amount'),
                ];
            })
            ->values();

        $apiKey = !empty($user->gemini_api_key) ? Crypt::decryptString($user->gemini_api_key) : null;
        $gemini = new GeminiService($apiKey);
        $recommendations = $gemini->getBudgetRecommendations($spendingData);

        return response()->json([
            'recommendations' => $recommendations,
            'currentSpending' => $spendingData,
        ]);
    }

    /**
     * Chat with AI financial advisor
     */
    public function chat(Request $request)
    {
        $request->validate([
            'message' => 'required|string',
        ]);

        $user = auth()->user();

        // Prepare context
        $totalIncome = $user->transactions()->where('type', 'income')->sum('amount');
        $totalExpenses = $user->transactions()->where('type', 'expense')->sum('amount');
        
        $monthlyIncome = $user->transactions()
            ->where('type', 'income')
            ->whereMonth('date', now()->month)
            ->whereYear('date', now()->year)
            ->sum('amount');

        $monthlyExpenses = $user->transactions()
            ->where('type', 'expense')
            ->whereMonth('date', now()->month)
            ->whereYear('date', now()->year)
            ->sum('amount');

        $context = [
            'balance' => $totalIncome - $totalExpenses,
            'monthlyIncome' => $monthlyIncome,
            'monthlyExpenses' => $monthlyExpenses,
        ];

        $apiKey = !empty($user->gemini_api_key) ? Crypt::decryptString($user->gemini_api_key) : null;
        $gemini = new GeminiService($apiKey);
        $response = $gemini->chat($request->message, $context);

        return response()->json([
            'response' => $response,
            'message' => $request->message,
        ]);
    }
}
